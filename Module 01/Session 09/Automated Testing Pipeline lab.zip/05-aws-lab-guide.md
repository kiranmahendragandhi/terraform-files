# Hands-On Lab: Automated Testing Pipeline on AWS

This lab deploys a real AWS CodePipeline + CodeBuild pipeline implementing:
Lint -> Unit Test -> Integration Test -> Quality Gate -> Smoke Test -> Manual
Approval, using the code in this repo.

## Prerequisites
- AWS account with permissions for CodeCommit, CodeBuild, CodePipeline, IAM, S3
- AWS CLI v2 configured (`aws configure`)
- Git installed
- (Optional) Docker, if you want to run the tests locally before pushing

## Step 1 — Run the Tests Locally First (Shift-Left in Practice)
```bash
cd automated-testing-pipeline-lab
python3 -m venv .venv && source .venv/bin/activate
pip install -r app/requirements.txt
pip install pytest pytest-cov pytest-mock flake8 bandit

# Unit tests (fast, no AWS needed)
export PYTHONPATH=.
pytest tests/unit -m unit -c ci/pytest.ini \
  --cov=app --cov-config=ci/.coveragerc \
  --cov-report=term-missing --cov-fail-under=80 -v
```
You should see all unit tests pass and coverage printed in the terminal —
this is exactly what CodeBuild will run in the `UnitTest` stage.

## Step 2 — Deploy the Pipeline Infrastructure
```bash
aws cloudformation deploy \
  --template-file infra/codepipeline.yaml \
  --stack-name testing-pipeline-lab \
  --capabilities CAPABILITY_NAMED_IAM \
  --parameter-overrides RepositoryName=automated-testing-pipeline-lab CoverageThreshold=80
```
This creates:
- A CodeCommit repo
- An S3 artifact bucket
- CodeBuild projects for each test stage (Lint, UnitTest, IntegrationTest,
  QualityGate, SmokeTest)
- A CodePipeline wiring them together with a manual approval gate before prod

Get outputs (repo clone URL, etc.):
```bash
aws cloudformation describe-stacks --stack-name testing-pipeline-lab \
  --query "Stacks[0].Outputs"
```

## Step 3 — Push This Code to CodeCommit
```bash
git init
git add .
git commit -m "Initial commit: automated testing pipeline lab"
git remote add origin <RepositoryCloneUrlHttp from Step 2 outputs>
git push -u origin main
```
Pushing to `main` automatically triggers the pipeline (CodePipeline polls /
uses an EventBridge rule on CodeCommit by default when created via this
template's `Source` action).

## Step 4 — Watch the Pipeline Run
```bash
aws codepipeline get-pipeline-state --name testing-pipeline-lab-pipeline
```
Or open the CodePipeline console: each stage — **Lint -> UnitTest ->
IntegrationTest -> QualityGate -> SmokeTest -> ManualApprovalForProd** — will
show green as it passes. Click into any CodeBuild stage to see the pytest
output and the JUnit "Reports" tab with per-test pass/fail detail.

## Step 5 — Inspect the Quality Gate Decision
After the `QualityGate` stage runs, download `reports/quality-gate-result.json`
from the stage's output artifact in S3 (or view it in the CodeBuild build
logs) to see the consolidated pass/fail decision:
```json
{
  "overall_result": "PASS",
  "checks": {
    "unit_tests": {"passed": true, "total": 14, "failures": 0},
    "integration_tests": {"passed": true, "total": 3, "failures": 0},
    "coverage": {"passed": true, "coverage_percent": 92.1, "threshold": 80},
    "security": {"passed": true, "high_severity_count": 0}
  }
}
```

## Step 6 — See a Gate Failure on Purpose
Break coverage intentionally to see the pipeline stop:
```bash
git checkout -b break-coverage
# Add a new function to app/calculator.py with NO test for it, e.g.:
#   def power(a, b): return a ** b
git add . && git commit -m "Add untested function" && git push origin break-coverage
```
Merge to `main` (or point the pipeline's BranchName parameter at this branch)
and watch the `UnitTest` stage fail with `--cov-fail-under=80`, stopping the
pipeline before it ever reaches IntegrationTest or Deploy. This demonstrates
shift-left: the cheapest stage catches the problem first.

## Step 7 (Extension) — Add Real Deploy Stages
The template leaves `DeployStaging` and `DeployProd` as placeholders. To make
this a complete pipeline:
1. Package `app/` as a Lambda function or container image in a `Build` stage.
2. Add a CodePipeline **Deploy** action using `AWS::CodePipeline` +
   CloudFormation (SAM/CDK) or CodeDeploy targeting ECS/Lambda/EC2.
3. Set `STAGING_BASE_URL` in `SmokeTestProject`'s environment variables to the
   real deployed endpoint (API Gateway URL / ALB DNS name) so
   `tests/smoke/test_smoke.py` hits the actual staging environment.
4. Add CloudWatch Alarms on the production deployment (error rate, latency)
   wired to CodeDeploy automatic rollback — this is the "shift-right" half of
   the strategy described in `01-shift-left-testing.md`.

## Step 8 (Extension) — Notify on Quality Gate Failure
Add an EventBridge rule on `aws.codepipeline` `CodePipeline Stage Execution
State Change` events filtered to `state: FAILED` and `stage: QualityGate`,
targeting a Lambda that posts to Slack/Teams/email (SNS topic) with the
contents of `reports/quality-gate-result.json`.

## Cleanup
```bash
aws cloudformation delete-stack --stack-name testing-pipeline-lab
# Also empty/delete the S3 artifact bucket manually if versioning retained objects
```

## Cost Note
CodeBuild `BUILD_GENERAL1_SMALL`/`MEDIUM` instances are billed per build-minute
(a few cents per run for this lab's small builds); CodePipeline is ~$1/month
per active pipeline. CodeCommit and S3 storage for this lab's size are
effectively free-tier. Delete the stack when done to avoid ongoing charges.
