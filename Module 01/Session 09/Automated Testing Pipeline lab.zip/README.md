# Automated Testing in Pipelines — Documentation + Hands-On AWS Lab

A complete, self-contained package covering:
- Shift-left testing concepts
- Test stages in CI/CD
- pytest for automated testing
- Quality gates and reports

...plus a working Python codebase and AWS infrastructure to actually run it.

## Structure
```
docs/
  01-shift-left-testing.md        <- concepts & theory
  02-test-stages-in-cicd.md       <- pipeline stage design
  03-pytest-guide.md              <- pytest patterns used in this repo
  04-quality-gates-and-reports.md <- how the gate & reports work
  05-aws-lab-guide.md             <- STEP-BY-STEP: deploy & run on AWS

app/                    <- sample application (calculator + DynamoDB-backed inventory service)
tests/
  unit/                 <- fast isolated tests (pytest -m unit)
  integration/          <- tests against real DynamoDB Local/LocalStack (pytest -m integration)
  smoke/                <- tests against deployed staging endpoint (pytest -m smoke)
  conftest.py           <- shared fixtures

quality_gates/
  quality_gate.py        <- aggregates JUnit + coverage + security reports -> pass/fail

ci/
  pytest.ini, .coveragerc
  buildspec-lint.yml
  buildspec-unit.yml
  buildspec-integration.yml
  buildspec-quality-gate.yml
  buildspec-smoke.yml

infra/
  codepipeline.yaml     <- CloudFormation: CodeCommit + CodeBuild x5 + CodePipeline
```

## Quickest Path to Running This
1. Read `docs/01` through `docs/04` for the concepts (15–20 min read).
2. Follow `docs/05-aws-lab-guide.md` step by step to deploy the pipeline to
   your AWS account and watch it run end-to-end, including deliberately
   breaking coverage to see the quality gate block a release.

## Local Quick Test (no AWS needed)
```bash
pip install -r app/requirements.txt pytest pytest-cov pytest-mock
export PYTHONPATH=.
pytest tests/unit -m unit -c ci/pytest.ini --cov=app --cov-config=ci/.coveragerc --cov-fail-under=80 -v
```

## Pipeline Flow Implemented
```
Source (CodeCommit)
  -> Lint (flake8 + bandit)
  -> UnitTest (pytest -m unit, coverage >= 80%)
  -> IntegrationTest (pytest -m integration, DynamoDB Local)
  -> QualityGate (quality_gate.py: aggregates all signals -> pass/fail)
  -> [Deploy to Staging]   <- placeholder, see lab guide "Extensions"
  -> SmokeTest (pytest -m smoke against real staging URL)
  -> ManualApprovalForProd
  -> [Deploy to Production] <- placeholder, see lab guide "Extensions"
```
